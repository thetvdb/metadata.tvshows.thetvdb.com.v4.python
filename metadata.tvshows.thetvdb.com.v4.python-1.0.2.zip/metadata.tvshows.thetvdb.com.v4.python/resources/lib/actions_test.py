import unittest

from actions import run


class TestActions(unittest.TestCase):

    def test_login(self):
        self.assertEqual(True, True)


if __name__ == '__main__':
    unittest.main()
